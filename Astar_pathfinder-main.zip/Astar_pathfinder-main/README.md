# Astar_pathfinder
    A program to find out an optimal route from RGIA airport to BITS Hyderabad. 
    It uses A* search algorithm with transit_time as the heuristic function .
